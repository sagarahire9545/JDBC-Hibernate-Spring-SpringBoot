import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Demo {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		//registering driver
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver loaded..");
		
		//create connection
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/data","root","root");
		
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter id:");
		int n=sc.nextInt();
		
		System.out.println("Enter name:");
		String name=sc.next();
		
		//create query
		String q="insert into data values(?,?)";
		PreparedStatement ptmt=con.prepareStatement(q);
		ptmt.setInt(1, n);
		ptmt.setString(2, name);
		
		ptmt.executeUpdate();
		
		System.out.println("Data inserted...");
	
		ptmt.close();
		con.close();
		
		
		
	}

}
