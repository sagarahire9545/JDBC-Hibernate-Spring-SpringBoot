package EmployeeJdbcDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import jdbc_ex1.MyConnection;

public class TestMyConnection {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con=MyConnection.getConnection();
		System.out.println("Connection successufully........");

	}

}
