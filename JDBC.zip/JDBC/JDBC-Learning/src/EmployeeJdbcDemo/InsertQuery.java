package EmployeeJdbcDemo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

import jdbc_ex1.MyConnection;

public class InsertQuery {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Connection con = MyConnection.getConnection();

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter employee id: ");
		int id = sc.nextInt();

		System.out.println("Enter employee first_name: ");
		String fn = sc.next();

		System.out.println("Enter employee last_name: ");
		String ln = sc.next();

		System.out.println("Enter employee salary: ");
		long salary = sc.nextLong();

		System.out.println("Enter employee Join Date yr/month/day: ");
		String jd = sc.next();

		System.out.println("Enter employee gender: ");
		String gender = sc.next();

		String q = "insert into employees(empId,First_Name,Last_Name,empSalary,Join_Data,gender) values(?,?,?,?,?,?)";

		PreparedStatement ptmt = con.prepareStatement(q);
		ptmt.setInt(1, id);
		ptmt.setString(2, fn);
		ptmt.setString(3, ln);
		ptmt.setLong(4, salary);
		ptmt.setString(5, jd);
		ptmt.setString(6, gender);

		ptmt.executeUpdate();
		System.out.println("Data inserted...........");

		ptmt.close();
		con.close();

	}

}
