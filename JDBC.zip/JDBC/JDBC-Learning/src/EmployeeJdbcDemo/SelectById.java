package EmployeeJdbcDemo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import jdbc_ex1.MyConnection;

public class SelectById {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		Connection con = MyConnection.getConnection();
//		
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter the id: ");
//		int id=sc.nextInt();

		// String q="select * from employees where emp_id="+id;
		String q = "select * from employees";

		Statement stmt = con.createStatement();

		ResultSet rs = stmt.executeQuery(q);

		while (rs.next()) {
			System.out.print(rs.getInt(1) + " ");
			System.out.print(rs.getString(2) + " ");
			System.out.print(rs.getString(3) + " ");
			System.out.print(rs.getLong(4) + " ");
			System.out.print(rs.getString(5) + " ");
			System.out.print(rs.getString(6) + " "); // System.out.print(rs.getInt(7));

		}

		stmt.close();
		con.close();

	}

}
