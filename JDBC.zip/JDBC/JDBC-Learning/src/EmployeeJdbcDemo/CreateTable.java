package EmployeeJdbcDemo;

import java.sql.Connection;
import java.sql.DriverManager;

import jdbc_ex1.MyConnection;

public class CreateTable {

	public static void main(String[] args) {
		

   }
}
