
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTable {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		// loading the driver
		Class.forName("com.mysql.jdbc.Driver");

		// creating connection
		String url = "jdbc:mysql://localhost:3306/mydata";
		String username = "root";
		String password = "root";

		// Driver manager
		Connection con = DriverManager.getConnection(url, username, password);

		// create a query
		String q = "create table Sysmbiosi2(s_id int(20) primary key not null,s_dept varchar(20))";

		Statement stmt = con.createStatement();

		stmt.executeUpdate(q);
		System.out.println("Table created....");

		stmt.close();
		con.close();
	}

}
