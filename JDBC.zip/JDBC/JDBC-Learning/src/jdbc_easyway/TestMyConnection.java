package jdbc_easyway;

import java.sql.Connection;
import java.sql.SQLException;

public class TestMyConnection {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Connection con = MyConnection.getConnection();
		System.out.println("Connected successfully...");
		
	}

}
