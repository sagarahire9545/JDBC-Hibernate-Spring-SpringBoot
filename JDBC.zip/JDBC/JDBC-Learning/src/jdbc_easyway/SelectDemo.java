package jdbc_easyway;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectDemo {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

		Connection con = MyConnection.getConnection();
		try
		{
			String query="select * from table1";
			Statement stat=con.createStatement();
			
			ResultSet rs=stat.executeQuery(query);
			
			while(rs.next())
			{
				System.out.print("  "+rs.getInt(1));
				System.out.print("  "+rs.getString(2));
				System.out.print("  "+rs.getString(3)+"\n");
			}
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		con.close();
	}

}
