package jdbc_easyway;

import java.sql.Connection;
//import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {

			Connection con = MyConnection.getConnection();

			// Scanner class
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter id: ");
			int id = sc.nextInt();

			System.out.println("Enter name: ");
			String name = sc.next();

			System.out.println("Enter city: ");
			String city = sc.next();

			// Query for inserting values
			String q = "insert into table1 values(" + id + ",'" + name + "','" + city + "')";

			Statement stmt = con.createStatement();

			int rows = stmt.executeUpdate(q);

			if (rows > 0) {
				System.out.println(rows + " Rows inserted");
			} else {
				System.out.println("Insertion failed");
			}

			con.close();

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}

	}

}
