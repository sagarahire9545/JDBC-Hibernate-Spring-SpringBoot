package jdbc_easyway;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateDemo {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		
		try {
			Connection con = MyConnection.getConnection();
			
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter new Name: ");
			String name=sc.next();
			
			System.out.println("Enter new  city: ");
			String city=sc.next();
			
			System.out.println("Enter the  id: ");
			int id=sc.nextInt();
			
			// query for update name and city using id 
			String query="update table1 "
					+ "set tName=? , tCity=? "
					+ "where tId=?  ";
			
			
			// using prepared statement
			PreparedStatement ptmt=con.prepareStatement(query);
	
			ptmt.setString(1, name);
			ptmt.setString(2, city);
			ptmt.setInt(3, id);
			
			ptmt.executeUpdate();
			
			System.out.println("done................");
			
			con.close();
			
			
		}
		catch(Exception e)
		{
			System.out.println(e);
			
		}
		
	}

}
