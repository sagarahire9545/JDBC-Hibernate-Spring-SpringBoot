package jdbc_learning;

import java.sql.*;

public class FirstJdbc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
			// loading the driver
			Class.forName("com.mysql.jdbc.Driver");
			
			//creating connection
			
			String url="jdbc:mysql://localhost:3306/mydata";
			String username="root";
			String password="root";
			
			//Driver manager
			Connection con=DriverManager.getConnection(url,username,password);
			
			//create a query
			
			String q="create table table2(tId int(20) primary key auto_increment,"
					+ "tName varchar(200) not null,"
					+ "tCity varchar(400))";

			//create a statement
			Statement stmt=con.createStatement();
			stmt.executeUpdate(q);
			System.out.println("Table2 is created....");
			
			con.close();
			
		}catch(Exception e){
			e.printStackTrace();
			
		}

	}


}
