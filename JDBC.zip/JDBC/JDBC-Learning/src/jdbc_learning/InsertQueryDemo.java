package jdbc_learning;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;
import java.io.*;

public class InsertQueryDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {

			Class.forName("com.mysql.jdbc.Driver");

			// create connection
			String url = "jdbc:mysql://localhost:3306/mydata";
			String username = "root";
			String password = "root";

	    	Connection con = DriverManager.getConnection(url, username, password);

			// Create a query

			String q = "insert into table1 values(?,?,?)";

			// create a preparedStatement object
			PreparedStatement psmt = con.prepareStatement(q);


			Scanner sc =new Scanner(System.in);
			System.out.println("Enter id: ");
			int id = sc.nextInt();

			System.out.println("Enter name: ");
			String name = sc.next();

			System.out.println("Enter city: ");
			String city = sc.next();

			psmt.setInt(1, id);
			psmt.setString(2, name);
			psmt.setString(3, city);

			psmt.executeUpdate();

			System.out.println("Data is inserted....");

			con.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
