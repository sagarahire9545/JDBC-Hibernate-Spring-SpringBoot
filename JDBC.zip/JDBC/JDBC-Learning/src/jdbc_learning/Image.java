package jdbc_learning;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Image {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydata", "root", "root");

			String q = "insert into images(pic) values(?)";

			PreparedStatement pstmt = con.prepareStatement(q);

			FileInputStream fis = new FileInputStream("C:\\Users\\SAGAR AHIRE\\Desktop\\Alone.jpg");
			pstmt.setBinaryStream(1, fis, fis.available());

			pstmt.executeUpdate();
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
