package jdbc_ex1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {

	public static Connection getConnection()  throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver loaded...");
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydata","root","root");
		return con;
	}

}
