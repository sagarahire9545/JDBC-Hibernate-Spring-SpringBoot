package jdbc_ex1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import jdbc_easyway.MyConnection;

public class UpdateQuery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Connection con = MyConnection.getConnection();

			Scanner sc = new Scanner(System.in);
			System.out.println("Enter new name: ");
			String n = sc.next();

			System.out.println("Enter new city: ");
			String c = sc.next();

			System.out.println("Enter id: ");
			int id = sc.nextInt();

			String q = "update student "
					+ "set s_name=?,s_city=? "
					+ "where s_id=?";

			PreparedStatement ptmt = con.prepareStatement(q);

			ptmt.setString(1, n);
			ptmt.setString(2, c);
			ptmt.setInt(3, id);
			

			ptmt.executeUpdate();
			
			System.out.println("done................");

			con.close();

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
