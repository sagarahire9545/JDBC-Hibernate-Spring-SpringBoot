package jdbc_ex1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;


public class DeleteQuery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		try {
			Connection con = MyConnection.getConnection();
			
			Scanner sc=new Scanner(System.in);
			
			System.out.println("Enter the id: ");
			int id =sc.nextInt();
			
			
			String q="delete from student where s_id=?";
			
			PreparedStatement ptmt=con.prepareStatement(q);
			ptmt.setInt(1, id);
			
			int row=ptmt.executeUpdate();
			System.out.println(" ");
			System.out.println(row +"Row deleted.");
		
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

}
