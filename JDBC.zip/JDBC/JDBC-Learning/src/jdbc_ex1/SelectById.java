package jdbc_ex1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class SelectById {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Statement stmt = null;
			Connection con = MyConnection.getConnection();

			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the id: ");
			int id = sc.nextInt();

			String q = "select * from student where s_id=" + id;

			stmt = con.createStatement();

			ResultSet rs = stmt.executeQuery(q);

			while (rs.next()) {
				System.out.print("  " + rs.getInt(1));
				System.out.print("  " + rs.getString(2));
				System.out.print("  " + rs.getString(3) + "\n");
			}
			con.close();

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
