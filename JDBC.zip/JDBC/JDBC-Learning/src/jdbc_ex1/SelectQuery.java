package jdbc_ex1;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jdbc_easyway.MyConnection;

public class SelectQuery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			Connection con = MyConnection.getConnection();
			
			
			String q="select * from student ";
			
			Statement stmt=con.createStatement();
			ResultSet set=stmt.executeQuery(q);
			
			while(set.next()) {
				System.out.print("  "+set.getInt(1));
				System.out.print("  "+set.getString(2));
				System.out.print("  "+set.getString(3)+"\n");

			}	
			con.close();
		} catch (ClassNotFoundException | SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
		
     

	}

}
