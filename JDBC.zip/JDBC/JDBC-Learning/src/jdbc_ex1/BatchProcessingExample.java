package jdbc_ex1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class BatchProcessingExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Connection con = MyConnection.getConnection();

			Scanner sc = new Scanner(System.in);

			System.out.println("Enter student id: ");
			int id = sc.nextInt();

			System.out.println("Enter student name: ");
			String name = sc.next();

			System.out.println("Enter student city: ");
			String city = sc.next();

			String q = "insert into student values(?,?,?)";

			PreparedStatement ptmt = con.prepareStatement(q);
			ptmt.setInt(1, id);
			ptmt.setString(2, name);
			ptmt.setString(3, city);

			ptmt.addBatch();

			// System.out.println("You want add more data y/n");

			// String ans = sc.next();

			ptmt.executeBatch(); // for executing batch
			System.out.println("Record successfully inserted...");

			con.close();

		} catch (ClassNotFoundException | SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	

}
