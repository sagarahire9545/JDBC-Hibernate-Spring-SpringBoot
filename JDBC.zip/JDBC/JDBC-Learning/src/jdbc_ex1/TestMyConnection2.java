package jdbc_ex1;

import java.sql.Connection;
import java.sql.SQLException;

public class TestMyConnection2 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		Connection con=MyConnection.getConnection();
		System.out.println("Connection successufully........");
		

	}

}
