package com.easyway;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectQuery {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Connection con = MyConnection.getConnection();

		String q = "select *from employee ";

		Statement stmt = con.createStatement();

		ResultSet set=stmt.executeQuery(q);
		
		while(set.next()) {
			System.out.println(set.getInt(1));
			System.out.println(set.getString(2));
			System.out.println(set.getString(3));
			
			
		}

		stmt.close();
		con.close();

	}

}
