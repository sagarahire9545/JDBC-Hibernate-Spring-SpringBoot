package com.easyway;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.mysql.cj.protocol.Resultset;

public class SelectById {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Connection con = MyConnection.getConnection();

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your id: ");
		int id = sc.nextInt();

		String q = "select *from employee where id=" + id;

		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(q);

		if (rs.next()) {
			System.out.println(rs.getInt(1));
			System.out.println(rs.getString(2));
			System.out.println(rs.getString(3));
		} else {
			System.out.println("Invalid data...");

		}

		stmt.close();
		con.close();

	}

}
