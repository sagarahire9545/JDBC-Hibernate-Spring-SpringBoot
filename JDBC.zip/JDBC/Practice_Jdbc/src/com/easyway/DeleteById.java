package com.easyway;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteById {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Connection con = MyConnection.getConnection();

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your id: ");
		int id = sc.nextInt();

		String q = "delete from employee where id=" + id;

		PreparedStatement ptmt = con.prepareStatement(q);
		ptmt.executeUpdate();

		System.out.println("Data deleted..");

		ptmt.close();
		con.close();

	}

}
