package com.easyway;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Scanner;

public class InsertQuery {

	public static void main(String[] args) {

		try {
			
			//calling object of connection
			Connection con = MyConnection.getConnection();

			Scanner sc = new Scanner(System.in);

			System.out.println("Enter employee id:");
			int id = sc.nextInt();

			System.out.println("Enter name:");
			String name = sc.next();

			System.out.println("Enter city:");
			String city = sc.next();

			//creating query
			String q = "insert into employee values(?,?,?)";

			//creating statement 
			PreparedStatement ptmt = con.prepareStatement(q);
			ptmt.setInt(1, id);
			ptmt.setString(2, name);
			ptmt.setString(3, city);
			
			//execute the statement
			ptmt.executeUpdate();

			System.out.println("Data inserted....");
			ptmt.close();
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
