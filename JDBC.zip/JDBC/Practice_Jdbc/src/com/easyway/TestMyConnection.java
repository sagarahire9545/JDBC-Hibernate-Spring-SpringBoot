package com.easyway;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestMyConnection {
	
	 public static void main(String[] args) throws ClassNotFoundException, SQLException {
	
		Connection con=MyConnection.getConnection();
		System.out.println("Connection successfully...");


	}
	
}
