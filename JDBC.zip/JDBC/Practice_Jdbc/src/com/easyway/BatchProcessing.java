package com.easyway;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class BatchProcessing {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Connection con = MyConnection.getConnection();
		System.out.println("Connection successfully......");

		Scanner sc = new Scanner(System.in);
		System.out.println("Batch Processing test...");
		System.out.println("--------------------------");

		System.out.println("Enter your id: ");
		int id = sc.nextInt();

		System.out.println("Enter your name: ");
		String name = sc.next();

		System.out.println("Enter your city");
		String city = sc.next();

		String q = "insert into student values(?,?,?)";
		String q1 = "insert into employee values(?,?,?)";

		PreparedStatement ptmt = con.prepareStatement(q);
		ptmt.setInt(1, id);
		ptmt.setString(2, name);
		ptmt.setString(3, city);
		ptmt.addBatch();

		PreparedStatement ptmt1 = con.prepareStatement(q1);
		ptmt1.setInt(1, id);
		ptmt1.setString(2, name);
		ptmt1.setString(3, city);
		ptmt1.addBatch();

		ptmt.executeBatch();
		ptmt1.executeBatch();

		System.out.println("Data inserted........!");
		ptmt.close();
		ptmt1.close();
		con.close();
	}

}
