package com.easyway;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class UpdateRecord {

	public static void main(String[] args) {

		try {

			Connection con = MyConnection.getConnection();

			Scanner sc = new Scanner(System.in);

			System.out.println("Enter your name: ");
			String name = sc.next();

			System.out.println("Enter your city: ");
			String city = sc.next();

			System.out.println("Enter your id: ");
			int id = sc.nextInt();

			String q = "update employee " + " set 'name=?',set 'city=?' " + "  where id=?";

			PreparedStatement ptmt = con.prepareStatement(q);
			ptmt.setString(1, name);
			ptmt.setString(2, city);
			ptmt.setInt(3, id);

			int result = ptmt.executeUpdate();

			System.out.println("Data is updated..." + result);

			ptmt.close();
			con.close();

		} catch (Exception e) {
			System.out.println(e);

		}

	}

}
