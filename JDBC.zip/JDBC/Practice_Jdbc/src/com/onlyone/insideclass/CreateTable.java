package com.onlyone.insideclass;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class CreateTable {

	public static void main(String[] args) {

		try {

			// Loading the driver class
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver loaded");

			// Creating connection
			String url = "jdbc:mysql://localhost:3306/jdbc";
			String username = "root";
			String password = "root";

			// Driver Manager
			Connection con = DriverManager.getConnection(url, username, password);
			System.out.println("Connection successfully");

			// Creating query
			String q = "create table employee(id int(20),name varchar(50),city varchar(50))";
             
			
			// Statement
			Statement stmt = con.createStatement();
			stmt.executeUpdate(q);
			
			System.out.println("Table craeted.....");

			stmt.close();
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
