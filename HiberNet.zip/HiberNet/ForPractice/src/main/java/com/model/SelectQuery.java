package com.model;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class SelectQuery {

	public static void main(String[] args) {

		Configuration cfg=new Configuration();
		cfg.configure("com/model/hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		
	   Session session=factory.openSession();
	   Transaction tx=session.beginTransaction();
		
		//get the data
//		String q="from Student";
//		Query query=session.createQuery(q);
//		
//		System.out.println(query);
//		List<Student> list=query.getResultList();
//		
//		for(Student x:list) {
//			System.out.println(x.getCity());
//		}
	   
	   Student st=(Student)session.load(Student.class, 2);
	   System.out.println("The data is:"+st);
		
		
		
		tx.commit();
		session.close();
		factory.close();
	}

}
