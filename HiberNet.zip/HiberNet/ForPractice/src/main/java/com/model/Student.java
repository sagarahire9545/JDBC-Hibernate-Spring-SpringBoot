package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Roll_No")
	private int rNo;

	@Column(name = "Name")
	private String name;
	private int phNo;
	private String city;

	public Student() {
		super();
	}

	public Student(int rNo, String name, int phNo, String city) {
		super();
		this.rNo = rNo;
		this.name = name;
		this.phNo = phNo;
		this.city = city;
	}

	public int getrNo() {
		return rNo;
	}

	public void setrNo(int rNo) {
		this.rNo = rNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPhNo() {
		return phNo;
	}

	public void setPhNo(int phNo) {
		this.phNo = phNo;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Student [rNo=" + rNo + ", name=" + name + ", phNo=" + phNo + ", city=" + city + "]";
	}

}
