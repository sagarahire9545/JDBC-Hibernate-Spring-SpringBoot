package com.model;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestStudent {

	public static void main(String[] args) {

		Configuration cfg=new Configuration();
		cfg.configure("com/model/hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();

		
		Student st=new Student();
		st.setrNo(1);
		st.setName("Ajay");
		st.setPhNo(987654678);
		st.setCity("Nashik");
		
		Session session =factory.openSession();
	    Transaction tx	=session.beginTransaction();
	    
	    
		
	    session.save(st);
		
		tx.commit();
		session.close();
		factory.close();
		
	}

}
