package com.abc;

import java.io.FileInputStream;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) throws Exception {
		System.out.println("Project started....");

		// SessionFactory factory=(SessionFactory) new
		// Configuration().buildSessionFactory();

		Configuration cfg = new Configuration();
		cfg.configure("com/abc/hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
//         System.out.println(factory);
//         System.out.println(factory.isClosed());

		Student st = new Student();
		st.setId(101);
		st.setName("Sagar");
		st.setCity("Ambasan");

		System.out.println(st);

		// Creating Address object

		Address ad = new Address();
		ad.setStreet("street-2");
		ad.setCity("Pune");
		ad.setIsopen(true);
		ad.setX(2000.900);
		ad.setAddDate(new Date());

		// Reading image
		FileInputStream fis = new FileInputStream("src/main/java/Alone.jpg");
		byte[] data = new byte[fis.available()];
		fis.read(data);
		ad.setImage(data);

		Session session = factory.openSession();
		org.hibernate.Transaction tx = session.beginTransaction();
		session.save(st);
		session.save(ad);

		tx.commit();

		session.close();
		System.out.println("Done...............");
	}
}
