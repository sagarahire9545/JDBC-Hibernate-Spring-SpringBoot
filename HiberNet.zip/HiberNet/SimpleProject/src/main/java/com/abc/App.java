package com.abc;

//import java.lang.invoke.ClassSpecializer.Factory;

import org.hibernate.Session;
import org.hibernate.SharedSessionContract;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.mysql.cj.xdevapi.SessionFactory;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Project Started...............");

		Configuration cfg = new Configuration();
		cfg.configure("com/abc/account.cfg.xml");
		org.hibernate.SessionFactory factory = cfg.buildSessionFactory();

		Account ac = new Account();
		ac.setAccNo(101);
		ac.setName("Priyanka");
		ac.setAdd("Nashik");
		ac.setAccbalance(10000);

		System.out.println(ac);

		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(ac);

		tx.commit();

		session.close();

	}
}
