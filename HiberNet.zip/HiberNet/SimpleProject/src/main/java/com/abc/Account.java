package com.abc;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Account {
	
	@Id
	private long accNo;
	private String name;
	private String add;
	private long Accbalance;
	
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(long accNo, String name, String add, long accbalance) {
		super();
		this.accNo = accNo;
		this.name = name;
		this.add = add;
		Accbalance = accbalance;
	}
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}
	public long getAccbalance() {
		return Accbalance;
	}
	public void setAccbalance(long accbalance) {
		Accbalance = accbalance;
	}
	@Override
	public String toString() {
		return "Account [accNo=" + accNo + ", name=" + name + ", add=" + add + ", Accbalance=" + Accbalance + "]";
	}
	
	

}
