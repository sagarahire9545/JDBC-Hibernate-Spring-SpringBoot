package configure_session;

//import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
//import org.hibernate.boot.registry.internal.StandardServiceRegistryImpl;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class SessionTest {

	static SessionFactory factory;

	public static SessionFactory mySessionFactory() {

		Configuration cfg=new Configuration().configure();
		
		ServiceRegistry registry=new StandardServiceRegistryBuilder().applySettings( cfg.getProperties()).build();
		SessionFactory factory=cfg.buildSessionFactory(registry);
//		
//		Session session = factory.openSession();
//		org.hibernate.Transaction tx = session.beginTransaction();

		System.out.println("Session started.......");
		return factory;

		
	}
}
