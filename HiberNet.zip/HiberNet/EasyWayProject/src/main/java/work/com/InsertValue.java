package work.com;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.model.Employee;

import configure_session.SessionTest;


public class InsertValue {

	

//	static Session s;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory factory=SessionTest.mySessionFactory();
	    Session session=factory.openSession();
	    org.hibernate.Transaction tx = session.beginTransaction();
	    
	    Employee emp=new Employee();
        emp.setEmpName("Suraj");
        emp.setJod(new Date());
        emp.setAdd("Beed");
        emp.setEmlSalary(21000);
        
        session.save(emp);
		

		// System.out.println(per);

		// SessionTest.sessionD();

		//Session session = factory.openSession();
		//org.hibernate.Transaction tx = session.beginTransaction();

		

		//session.close();
		tx.commit();

		System.out.println("Done Inserted values..........");

	}

}
