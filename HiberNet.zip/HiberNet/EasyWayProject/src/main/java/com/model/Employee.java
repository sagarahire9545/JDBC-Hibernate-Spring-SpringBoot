package com.model;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="Employee_details")
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column( name="empID")
	private int empId;
	
	@Column(name="Name")
	private String empName;
	
	@Column(name="addedDate")
	@Temporal(TemporalType.DATE)
	private Date jod;
	
	@Column(name="address")
	private String add;
	
	@Column(name="Salary")
	private double emlSalary;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int empId, String empName, Date dob, String add, double emlSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.jod = dob;
		this.add = add;
		this.emlSalary = emlSalary;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Date getJod() {
		return jod;
	}
	public void setJod(Date jod) {
		this.jod = jod;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}
	public double getEmlSalary() {
		return emlSalary;
	}
	public void setEmlSalary(double emlSalary) {
		this.emlSalary = emlSalary;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", jod=" + jod + ", add=" + add + ", emlSalary="
				+ emlSalary + "]";
	}
	
	
	
}

