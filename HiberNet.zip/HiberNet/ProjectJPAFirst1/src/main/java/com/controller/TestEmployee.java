package com.controller;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.model.Employee;

public class TestEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("e");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();

		Employee e1 = new Employee(1201, "Gopal", 40000, "Technical Manager");
		Employee e2 = new Employee(1202, "Manisha", 40000, "Proof Reader");
		Employee e3 = new Employee(1203, "Msthanvli", 40000, "Technical Writer");
		Employee e4 = new Employee(1204, "Satish", 30000, "Technical Writer");
		Employee e5 = new Employee(1205, "Krishna", 30000, "Technical Writer");
		Employee e6 = new Employee(1206, "Sagar", 350000, "Proof Reader");

		em.persist(e1);
		em.persist(e2);
		em.persist(e3);
		em.persist(e4);
		em.persist(e5);
		em.persist(e6);

		em.getTransaction().commit();
		System.out.println("Object persist");
	}

}
