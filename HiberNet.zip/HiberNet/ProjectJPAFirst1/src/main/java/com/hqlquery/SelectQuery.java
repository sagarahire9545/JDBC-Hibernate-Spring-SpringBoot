package com.hqlquery;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Query;

import com.model.Employee;

public class SelectQuery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("e");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		
//		String query="from Employee";
//		Query q=(Query) em.createQuery(query);
//		
		
		String query = "from Employee as a where  a.id=:n and a.salary=:x";
		Query q = (Query) em.createQuery(query);
		q.setParameter("n", 101);
		q.setParameter("x", 50000);
		
		List<Employee> list = q.list();
		for(Employee employee:list) {
			System.out.println(employee.getName());
		}
		em.getTransaction().commit();
		
	}

}
