package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee {
	@Id
	private int id;
	
	@Column(name="Ename")
	private String Name;
	
	@Column(name="Salary")
	private int salary;
	
	@Column(name="Deg")
	private String deg;
	
	
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Employee(int id, String name, int salary, String deg) {
		super();
		this.id = id;
		Name = name;
		this.salary = salary;
		this.deg = deg;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getName() {
		return Name;
	}



	public void setName(String name) {
		Name = name;
	}



	public int getSalary() {
		return salary;
	}



	public void setSalary(int salary) {
		this.salary = salary;
	}



	public String getDeg() {
		return deg;
	}



	public void setDeg(String deg) {
		this.deg = deg;
	}
	
	
	
	
	
}
