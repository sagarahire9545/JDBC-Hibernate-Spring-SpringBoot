package com.tut;

import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Project started...." );
        
        //SessionFactory factory=(SessionFactory) new Configuration().buildSessionFactory();
        
        Configuration cfg=new Configuration();
        cfg.configure("com/tut/hibernet.cfg.xml");
        org.hibernate.SessionFactory factory=cfg.buildSessionFactory();
//        System.out.println(factory);
//        System.out.println(factory.isClosed());
        
        Student st=new Student();
        st.setId(102);
        st.setName("Akshay");
        st.setCity("Pune");
        
        System.out.println(st);
        
        Session session=factory.openSession(); 
        org.hibernate.Transaction tx= session.beginTransaction();
        session.save(st);
        
        
        tx.commit();
        
        session.close();
        
        
       
    }
}
