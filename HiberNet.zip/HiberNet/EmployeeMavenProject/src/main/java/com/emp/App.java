package com.emp;

import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

import com.mysql.cj.xdevapi.SessionFactory;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Project started...." );
        
        //SessionFactory factory=(SessionFactory) new Configuration().buildSessionFactory();
        
        Configuration cfg=new Configuration();
        cfg.configure("com/emp/hibernate.cf.xml");
        org.hibernate.SessionFactory factory=cfg.buildSessionFactory();
//        System.out.println(factory);
//        System.out.println(factory.isClosed());
        
        Employee st=new Employee();
        st.setId(104);
        st.setName("Vishal");
        st.setCity("Nagar");
        
        System.out.println(st);
        
        Session session=((org.hibernate.SessionFactory) factory).openSession();
        org.hibernate.Transaction tx= session.beginTransaction();
        session.save(st);
        
        
        tx.commit();
        
        session.close();
        
        
       
    }
}
