package com.map1;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Question {

	@Id
	private int qId;
	private String question;

	@OneToOne
	private Answer ans;

	public Question() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Question(int qId, String question, Answer ans) {
		super();
		this.qId = qId;
		this.question = question;
		this.ans = ans;
	}

	public int getqId() {
		return qId;
	}

	public void setqId(int qId) {
		this.qId = qId;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public Answer getAns() {
		return ans;
	}

	public void setAns(Answer ans) {
		this.ans = ans;
	}

	@Override
	public String toString() {
		return "Question [qId=" + qId + ", question=" + question + "]";
	}

}
