package com.map1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MapTest {

	public static void main(String[] args) {

		System.out.println("Project started..............");
		Configuration cfg = new Configuration();
		cfg.configure("com/tut/hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

		Question question = new Question();
		question.setqId(101);
		question.setQuestion("What is Java?");

		Answer answer = new Answer();
		answer.setAnsId(201);
		answer.setAnswer("Java is a programming language.");
		question.setAns(answer);

		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();

		session.save(question);
		session.save(answer);

		tx.commit();
		
		session.close();
		factory.close();
	}

}
