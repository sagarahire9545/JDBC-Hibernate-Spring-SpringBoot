package com.embeddable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestEmneddable {

	public static void main(String[] args) {

		Configuration cfg=new Configuration();
		cfg.configure("com/tut/hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		
		Student st=new Student();
		st.setRollNo(1);
		st.setName("Rahul");
		st.setDegree("Engenniear");
		
		Certificate cert=new Certificate();
		cert.setCertName("Full Stack Developement");
		cert.setFees("120000");
		
		//save certifacate obj in student obj
		st.setCert(cert);

		session.save(st);
		
		tx.commit();
		session.close();
		factory.close();
		
	}

}
