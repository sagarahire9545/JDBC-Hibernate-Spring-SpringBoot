package com.embeddable;

import javax.persistence.Embeddable;

@Embeddable
public class Certificate {

	private String certName;
	private String fees;

	public Certificate() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Certificate(String certName, String fees) {
		super();
		this.certName = certName;
		this.fees = fees;
	}

	public String getCertName() {
		return certName;
	}

	public void setCertName(String certName) {
		this.certName = certName;
	}

	public String getFees() {
		return fees;
	}

	public void setFees(String fees) {
		this.fees = fees;
	}

	@Override
	public String toString() {
		return "Certificate [certName=" + certName + ", fees=" + fees + "]";
	}

}
