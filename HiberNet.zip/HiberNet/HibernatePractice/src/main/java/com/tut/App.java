package com.tut;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("com/tut/hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();

		Employee emp = new Employee();
		//emp.setEmpId(1); //auto-increment
		emp.setName("Sagar");
		emp.setJob(new Date());
		emp.setAdd("Satana");
		emp.setSalary(15000d);

		session.save(emp);

		tx.commit();
		session.close();
		factory.close();
	}
}
