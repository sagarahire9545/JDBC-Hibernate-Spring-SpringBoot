package com.tut;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity(name="employee_details")
public class Employee {

	@Id
	@Column(name="Id")
	@GeneratedValue(strategy = GenerationType.IDENTITY )
	private int empId;
	private String name;
	
	@Column(name="join_date")
	@Temporal(TemporalType.DATE)
	private Date job;
	
	@Column(name="address")
	private String add;
	
	@Column(name="Salary")
	private double salary;

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int empId, String name, Date job, String add, double salary) {
		super();
		this.empId = empId;
		this.name = name;
		this.job = job;
		this.add = add;
		this.salary = salary;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getJob() {
		return job;
	}

	public void setJob(Date job) {
		this.job = job;
	}

	public String getAdd() {
		return add;
	}

	public void setAdd(String add) {
		this.add = add;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", job=" + job + ", add=" + add + ", salary=" + salary
				+ "]";
	}

}
