package com.tut;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Fetch {

	public static void main(String[] args) {

		System.out.println("Project started.............");
		Configuration cfg=new Configuration();
		cfg.configure("com/tut/hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		
		Session session=factory.openSession();
		
//		Employee employee=session.get(Employee.class, 1);
//		System.out.println(employee.getName());
//		System.out.println(employee.getAdd());
//		
		
		Employee employee= session.load(Employee.class, 1);
		System.out.println(employee.getName()+" , "+employee.getSalary()+" , "+employee.getJob());
		
		session.close();
		factory.close();
		
	}

}
