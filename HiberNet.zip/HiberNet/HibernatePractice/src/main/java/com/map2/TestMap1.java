package com.map2;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestMap1 {

	public static void main(String[] args) {

		SessionFactory factory = new Configuration().configure("com/tut/hibernate.cfg.xml").buildSessionFactory();

		Question2 question = new Question2();
		question.setqId(1);
		question.setQuestion("What is hibernate?");

		Answer1 answer = new Answer1();
		answer.setAnswerId(201);
		answer.setAnswer("ORM tool.");
		answer.setQuestion(question);

		Answer1 answer1 = new Answer1();
		answer1.setAnswerId(202);
		answer1.setAnswer("Framework.");
		answer1.setQuestion(question);

		List<Answer1> list = new ArrayList<Answer1>();
		list.add(answer);
		list.add(answer1);

		question.setAnswers(list);

		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();

		session.save(question);
		session.save(answer);
		session.save(answer1);

		tx.commit();
		session.close();
		factory.close();
	}

}
