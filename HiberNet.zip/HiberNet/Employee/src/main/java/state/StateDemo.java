package state;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.abc.Certificate;
import com.abc.Student;

public class StateDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Configuration cfg = new Configuration();
		cfg.configure("com/abc/hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

		Student student = new Student();
		student.setName("Sagar");
		student.setRollNo(04);
		student.setAdd("Amaravti");
		
		Certificate ce= new Certificate();
		ce.setCourse("BCA");
		ce.setDuration("5-month");
		
		
		student.setCert(ce);
         //Transient State
		
		Session s=factory.openSession();
		Transaction tx= s.beginTransaction();
		
		
		s.save(student);
		//Persient state
		
		
		tx.commit();
		s.close();
		factory.close();

	}

}
