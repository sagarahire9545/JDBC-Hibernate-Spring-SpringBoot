package com.map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class FetchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		Configuration cfg = new Configuration();
		cfg.configure("com/abc/hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		
		Session s=factory.openSession();
		Transaction tx=s.beginTransaction();
		
		Question q=(Question) s.get(Question.class, 121);
		System.out.println(q.getQuetionId());
		System.out.println(q.getQuestion());
		
		/*
		 * //lazy System.out.println(q.getAnswer().size());
		 */
		
		tx.commit();
		s.close();
		factory.close();

	}

}
