package com.map;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Configuration cfg = new Configuration();
		cfg.configure("com/abc/hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

		/*
		 * ---------------For one-to-one-------- //Creating questions Question que=new
		 * Question(); que.setQuetionId(121); que.setQuestion("What is class?");
		 * 
		 * //Creating answer Answer ans=new Answer(); ans.setAnswerId(202);
		 * ans.setAnswer("Blueprint of obj");
		 * 
		 * 
		 * que.setAnswer(ans);
		 */

		// OneToMany

		Question que1 = new Question();
		que1.setQuetionId(121);
		que1.setQuestion("What is Java?");

		Answer ans = new Answer();
		ans.setAnswerId(201);
		ans.setAnswer("Programming lannguage");
		ans.setQuestion(que1);
		
		Answer ans1 = new Answer();
		ans1.setAnswerId(202);
		ans1.setAnswer("Object oriented");
		ans1.setQuestion(que1);
		
		Answer ans2 = new Answer();
		ans2.setAnswerId(203);
		ans2.setAnswer("High level and simple language");
		ans2.setQuestion(que1);
		
		List<Answer> list= new ArrayList<Answer>();
		list.add(ans);
		list.add(ans1);
		list.add(ans2);
		
		que1.setAnswer(list);
		

		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		
		//save
		session.save(que1);
		session.save(ans);
		session.save(ans1);
		session.save(ans2);

		// session.save(que); //for one-to-one

		tx.commit();
		session.close();
		factory.close();

	}

}
