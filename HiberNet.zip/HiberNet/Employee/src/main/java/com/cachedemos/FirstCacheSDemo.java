package com.cachedemos;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.abc.Employee;

public class FirstCacheSDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory factory = new Configuration().configure("com/abc/hibernate.cfg.xml").buildSessionFactory();

		Session session = factory.openSession();

		// only one query fire and return multiple object result of same object

		Employee employee = session.get(Employee.class, 1);
		System.out.println(employee);

		Employee employee1 = session.get(Employee.class, 1);
		System.out.println(employee1);

		System.out.println(session.contains(employee));// checking object are already in cachee memory

		session.close();

	}

}
