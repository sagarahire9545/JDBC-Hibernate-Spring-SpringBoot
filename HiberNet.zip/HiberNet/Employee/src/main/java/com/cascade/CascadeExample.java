package com.cascade;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.map.Answer;
import com.map.Question;

public class CascadeExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory factory = new Configuration().configure("com/abc/hibernate.cfg.xml").buildSessionFactory();
		Session s = factory.openSession();

		Question q = new Question();
		q.setQuetionId(124);
		q.setQuestion("What is swing framework?");

		Answer ans1 = new Answer(301, "Use for development", q);
		Answer ans2 = new Answer(302, "Desktop", q);
		Answer ans3 = new Answer(303, "Learn programmer", q);

		List<Answer> list = new ArrayList<Answer>();
		list.add(ans1);
		list.add(ans2);
		list.add(ans3);
		
		q.setAnswer(list);

		Transaction tx = s.beginTransaction();

		s.save(q);

		tx.commit();
		s.close();
		factory.close();
	}

}
