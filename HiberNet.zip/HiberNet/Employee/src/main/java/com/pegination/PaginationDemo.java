package com.pegination;

import java.util.List;

import org.hibernate.query.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.abc.Employee;

public class PaginationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory factory= new Configuration().configure("com/abc/hibernate.cfg.xml").buildSessionFactory();
		Session s= factory.openSession();
		
		Query q=s.createQuery("from Employee");
		
		q.setFirstResult(0); //starting from index
		q.setMaxResults(2);  // end of element   
		
		List<Employee> list=q.list();
		
		for(Employee emp:list)
		{
			System.out.println(emp.getEmpName()+ " : "+emp.getAdd()+ " : "+emp.getEmlSalary()+ " : "+emp.getEmpId());
		}
		
		s.close();
		factory.close();
	}

}
