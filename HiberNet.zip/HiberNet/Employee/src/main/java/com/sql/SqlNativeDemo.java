package com.sql;

import java.util.Arrays;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.NativeQuery;

public class SqlNativeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SessionFactory factory= new Configuration().configure("com/abc/hibernate.cfg.xml").buildSessionFactory();
		Session s= factory.openSession();
		
		String query="select * from Employee";
		NativeQuery nq = s.createSQLQuery(query);
		
		//System.out.println(nq.getResultList());
		List<Object[]> list = nq.list();
		
		for(Object[] emp:list)
		{
			System.out.println(Arrays.deepToString(emp));
		}
		
		
		s.close();
		factory.close();

	}

}
