package com.mapping.xml;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class PersionMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SessionFactory factory = new Configuration().configure("com/abc/hibernate.cfg.xml").buildSessionFactory();
		
		Session session = factory.openSession();
		Transaction tx=session.beginTransaction();
		
		Person per=new Person(11,"ABC","Nashik","987654321");
		session.save(per);
		
		tx.commit();
		factory.close();
		session.close();

	}

}
