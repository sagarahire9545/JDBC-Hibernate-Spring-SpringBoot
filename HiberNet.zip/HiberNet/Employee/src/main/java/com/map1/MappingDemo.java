package com.map1;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MappingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Configuration cfg = new Configuration();
		cfg.configure("com/abc/hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

		Emp emp = new Emp();
		Emp emp1 = new Emp();

		emp.setEmpId(101);
		emp.setEmpName("Akshay");

		emp1.setEmpId(102);
		emp1.setEmpName("Naru");

		Project pr = new Project();
		Project pr1 = new Project();

		pr.setPid(11);
		pr.setProjectName("Library management system");

		pr1.setPid(22);
		pr1.setProjectName("Hostel management System.");

		List<Emp> list1 = new ArrayList<Emp>();
		List<Project> list2 = new ArrayList<Project>();

		list1.add(emp);
		list1.add(emp1);

		list2.add(pr);
		list2.add(pr1);

		emp.setProjects(list2);
		pr.setEmployees(list1);

		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();

		// save objects
		session.save(emp);
		session.save(emp1);
		session.save(pr);
		session.save(pr1);

		tx.commit();
		session.close();
		factory.close();
	}

}
