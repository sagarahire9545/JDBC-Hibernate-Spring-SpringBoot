package com.second_level;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.abc.Employee;

public class SecondLevelCacheDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory factory = new Configuration().configure("com/abc/hibernate.cfg.xml").buildSessionFactory();

		Session s1 = factory.openSession();

		// first
		Employee employee = s1.get(Employee.class, 1);
		System.out.println(employee);

		s1.close();

		Session s2 = factory.openSession();

		// second
		Employee employee1 = s2.get(Employee.class, 1);
		System.out.println(employee1);
		s2.close();

	}

}
