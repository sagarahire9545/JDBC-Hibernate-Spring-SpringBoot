package com.abc;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmbeddedDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Configuration cfg = new Configuration();
		cfg.configure("com/abc/hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

		Student st = new Student();
		st.setRollNo(12);
		st.setName("Sagar");
		st.setAdd("Nashik");

		Certificate certficate = new Certificate();
		certficate.setCourse("MCA");
		certficate.setDuration("2-month");
		
		st.setCert(certficate);

		Session s = factory.openSession();
		Transaction tx = s.beginTransaction();

		s.save(st);

		tx.commit();
		s.close();
		factory.close();
		

	}

}
