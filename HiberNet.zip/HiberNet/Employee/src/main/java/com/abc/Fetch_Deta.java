package com.abc;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Fetch_Deta {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg = new Configuration();
		cfg.configure("com/abc/hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();
		Employee employee = (Employee) session.load(Employee.class,2);

		System.out.println(employee);
		System.out.println(employee.getEmpName());

		session.close();
		factory.close();
	}

}
