package com.abc;


import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Project started............." );
        
        Configuration cfg =new Configuration();
        cfg.configure("com/abc/hibernate.cfg.xml");
        SessionFactory factory=cfg.buildSessionFactory();
        
        Employee emp=new Employee();
        emp.setEmpName("Suraj");
        emp.setJod(new Date());
        emp.setAdd("Beed");
        emp.setEmlSalary(21000);
        
        Employee emp1=new Employee();
        emp1.setEmpName("Akshay");
        emp1.setJod(new Date());
        emp1.setAdd("Ambasan");
        emp1.setEmlSalary(41000);
        
        System.out.println(emp);
        
        
        Session session = factory.openSession();
		org.hibernate.Transaction tx = session.beginTransaction();
		
		session.save(emp);
		session.save(emp1);

		
		tx.commit();
		session.close();
		System.out.println("done...........");
		
        
       
    }
}
