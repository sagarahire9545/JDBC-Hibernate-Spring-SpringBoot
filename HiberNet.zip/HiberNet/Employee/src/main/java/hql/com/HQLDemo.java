package hql.com;

import java.util.List;

import org.hibernate.query.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.abc.Employee;

public class HQLDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Configuration cfg = new Configuration();
		cfg.configure("com/abc/hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

		Session s = factory.openSession();
		// Transaction tx= s.beginTransaction();

//        String query="from Employee";
		// String query="from Employee where empId=5";
		// String query="from Employee where address='pune' ";

		String query = "from Employee as a where  a.add=:n and a.emlSalary=:x";
		Query q = s.createQuery(query);
		q.setParameter("n", "Ambasan");
		q.setParameter("x", 41000d);

		List<Employee> list = q.list();

		for (Employee emp : list) {
			// System.out.println(emp.getEmpName() + " : " + emp.getAdd());
			System.out.println(emp);
			System.out.println("------------------");
		}

		
		s.close();
		factory.close();
	}

}
