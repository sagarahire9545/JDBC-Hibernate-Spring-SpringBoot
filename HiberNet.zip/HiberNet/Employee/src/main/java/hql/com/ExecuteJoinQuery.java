package hql.com;
import org.hibernate.query.*;
import java.util.Arrays;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ExecuteJoinQuery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Execute join query
		// Question and Answer example and using inner join query

		Configuration cfg = new Configuration();
		cfg.configure("com/abc/hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Transaction tx = session.beginTransaction();

		String query = "select q.question,q.quetionId,a.answer from Question as q INNER JOIN q.answer as a ";
		Query q = session.createQuery(query);

//		int r=q.executeUpdate();
//		
//		System.out.println(r);

		List<Object[]> list = q.getResultList();

		for (Object[] arr : list)
		{
			System.out.println(Arrays.toString(arr));
			// System.out.println(arr);
		}

		System.out.println("Done...........................");

		tx.commit();

		session.close();
		factory.close();

	}

}
