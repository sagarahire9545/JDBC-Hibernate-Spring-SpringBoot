package hql.com;

import org.hibernate.query.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DeleteOpreation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Configuration cfg = new Configuration();
		cfg.configure("com/abc/hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

		Session s = factory.openSession();
		Transaction tx=s.beginTransaction();
		
		//apply delete query for specific record
		//String query = "delete from Employee where empId=6";

//		String query = "delete from Employee e where e.empId=:d";
//		Query query2 = s.createQuery(query);
//		query2.setParameter("d", 4);
//
//		int del = query2.executeUpdate();
		
		String q="delete from Employee e where e.empId=:d ";
	    Query query=s.createQuery(q);
	    int del=query.executeUpdate();
		
		System.out.println(del);
		System.out.println("Deleted.......!");
		
        tx.commit();
		s.close();
		factory.close();
	}

}



/*
 * Transaction tx = s.beginTransaction(); Query q2 =
 * s.createQuery("delete from Employee  where add=:c and empId=:i");
 * q2.setParameter("c", "Ambasan"); q2.setParameter("i", 7);
 * 
 * int r = q2.executeUpdate(); System.out.println("Deleted....");
 * System.out.println(r);
 * 
 * // tx.commit();
 */