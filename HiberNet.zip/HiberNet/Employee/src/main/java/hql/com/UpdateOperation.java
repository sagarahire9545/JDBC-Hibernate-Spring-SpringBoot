package hql.com;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class UpdateOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Configuration cfg=new Configuration();
		cfg.configure("com/abc/hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();

		Session s=factory.openSession();
		
		//Transaction req
		Transaction tx=s.beginTransaction();
		
		//String q="update Employee set add='Beed' where empName='Sachin'";
		String q="update Employee as e set e.add=:d where e.empName=:n";
		Query query=s.createQuery(q);
		query.setParameter("d", "Nashik");
		query.setParameter("n", "Ganesh");
		
		
		int r=query.executeUpdate();
		
		System.out.println(r);
		System.out.println("Record Updated..");
		
		tx.commit();
		s.close();
		
		factory.close();
	}

}
