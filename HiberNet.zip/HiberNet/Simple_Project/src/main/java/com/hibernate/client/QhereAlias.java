package com.hibernate.client;

import java.util.List;

import org.hibernate.query.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hibernate.model.College;

public class QhereAlias {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();

		String query = "from College as a where a.address=:x and a.country=:y";
		Query q = session.createQuery(query);

		q.setParameter("x", "Satana");
		q.setParameter("y", "India");

		List<College> list = q.list();

		for (College clg : list) {

			System.out.println(clg.getCollege_Name() + " : " + clg.getCollId() + " : " + clg.getClass());
		}

		session.close();
		factory.close();
	}

}
