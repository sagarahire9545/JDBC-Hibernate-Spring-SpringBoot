package com.hibernate.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Project {

	@Id
	private int pId;
	private String proName;
	private String duration;

	@ManyToOne
	private Employee employee;

	public Project() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Project(int pId, String proName, String duration, Employee employee) {
		super();
		this.pId = pId;
		this.proName = proName;
		this.duration = duration;
		this.employee = employee;
	}

	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	@Override
	public String toString() {
		return "Project [proName=" + proName + ", duration=" + duration + "]";
	}

}
