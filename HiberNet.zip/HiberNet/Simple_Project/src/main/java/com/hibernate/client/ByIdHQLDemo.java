package com.hibernate.client;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.model.College;

public class ByIdHQLDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
        Session session=factory.openSession();
       
        Transaction tx = session.beginTransaction();
        
        String query="from College where collId=2";
        Query q=session.createQuery(query);
       
        List<College> list=q.getResultList();
        
        for(College college:list) {
        	System.out.println(college.toString());
        }
		
        tx.commit();
		session.close();
		factory.close();
	}

}
