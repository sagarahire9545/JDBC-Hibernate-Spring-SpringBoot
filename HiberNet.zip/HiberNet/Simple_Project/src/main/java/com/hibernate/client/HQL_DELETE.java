package com.hibernate.client;

import java.util.Scanner;

import org.hibernate.query.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HQL_DELETE {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the id you are deleting: ");
		int collId = sc.nextInt();

		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();

		Query q = session.createQuery("delete from College where collId=:x");
		q.setParameter("x", collId);

		Transaction tx = session.beginTransaction();

		int r = q.executeUpdate();
		System.out.println(r);

		System.out.println("Deleted");

		tx.commit();
		session.close();
		factory.close();

	}

}
