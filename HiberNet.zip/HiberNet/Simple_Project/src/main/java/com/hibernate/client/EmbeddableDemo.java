package com.hibernate.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.model.Cerificate;
import com.hibernate.model.Student;

public class EmbeddableDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();

		Student st = new Student();
		st.setId(1);
		st.setName("ABC");

		Cerificate cert = new Cerificate();
		cert.setCourse("MCA");
		cert.setDuration("2-yrs");

		st.setCert(cert);

		Transaction tx = session.beginTransaction();
		
		session.save(st);
		

		tx.commit();
		session.close();
		factory.close();
	}

}
