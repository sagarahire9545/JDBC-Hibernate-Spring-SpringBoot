package com.hibernate.client;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.model.College;

public class CollegeInsertDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
       
		
        College clg=new College(1,"KAANMS College","Satana","India");
        College clg1=new College(1,"Symbiosis College","Pune","India");
        College clg2=new College(1,"Sinhgad College","Pune","India");
        College clg3=new College(1,"Ambedkar College","Aurangabad","India");

        Session session=factory.openSession();
        Transaction tx = session.beginTransaction();
        
        session.save(clg);
        session.save(clg1);
        session.save(clg2);
        session.save(clg3);
        
       
        tx.commit();
        session.close();
		factory.close();
	}

}
