package com.hibernate.client;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.model.Employee;
import com.hibernate.model.Project;

public class CascadeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory factory = new Configuration().configure().buildSessionFactory();

		Employee emp = new Employee();
		emp.setEmpId(2);
		emp.setName("abcd");

		Project p = new Project();
		p.setpId(201);
		p.setProName("abc..");
		p.setDuration("6-month");
		p.setEmployee(emp);

		Project p1 = new Project();
		p1.setpId(202);
		p1.setProName("cdr man sys..");
		p1.setDuration("4-month");
		p1.setEmployee(emp);

		Project p2 = new Project();
		p2.setpId(203);
		p2.setProName("xyz man sys..");
		p2.setDuration("2-month");
		p2.setEmployee(emp);

		List<Project> list = new ArrayList<Project>();
		list.add(p);
		list.add(p1);
		list.add(p2);

		emp.setProject(list);

		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();

		session.save(emp);
		

		session.close();
		factory.close();
	}

}
