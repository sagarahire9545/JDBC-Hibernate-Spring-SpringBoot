package com.hibernate.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hibernate.model.Project;

public class Fetch_Data {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();

		// lazy-type
		Project pr = session.get(Project.class, 102);
		System.out.println(pr.getDuration());
		System.out.println(pr.getProName());
		// System.out.println(pr);

		System.out.println(pr.getEmployee());
		System.out.println("-------------------------");

		Project pr1 = session.get(Project.class, 101);
//		System.out.println(pr1.getDuration());
//		System.out.println(pr1.getProName());

		System.out.println(pr1);

		session.close();
		factory.close();

	}

}
