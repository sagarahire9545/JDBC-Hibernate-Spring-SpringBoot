package com.hibernate.client;

import java.util.List;

import org.hibernate.query.*;

import com.hibernate.model.College;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HQL_College {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();

		String query = "from College";
		Query q = session.createQuery(query);

		List<College> list = q.getResultList();

		for (College college : list) {

			System.out.println(college.getAddress() + " : " + college.getCollege_Name() + " : " + college.getCountry());

			// System.out.println(college);
		}

		session.close();
		factory.close();
	}

}
