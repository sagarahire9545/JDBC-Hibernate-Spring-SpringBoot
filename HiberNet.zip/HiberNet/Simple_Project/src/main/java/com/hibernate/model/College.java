package com.hibernate.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="College_Details")
public class College {

	@Id
	@Column(name="College_Id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int collId;
	
	@Column(name="College_Name")
	private String college_Name;
	
	@Column(name="Address")
	private String address;
	
	@Column(name="Country")
	private String country;

	public College() {
		super();
		// TODO Auto-generated constructor stub
	}

	public College(int collId, String college_Name, String address, String country) {
		super();
		this.collId = collId;
		this.college_Name = college_Name;
		this.address = address;
		this.country = country;
	}

	public int getCollId() {
		return collId;
	}

	public void setCollId(int collId) {
		this.collId = collId;
	}

	public String getCollege_Name() {
		return college_Name;
	}

	public void setCollege_Name(String college_Name) {
		this.college_Name = college_Name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Override
	public String toString() {
		return "College [collId=" + collId + ", college_Name=" + college_Name + ", address=" + address + ", country="
				+ country + "]";
	}

}
