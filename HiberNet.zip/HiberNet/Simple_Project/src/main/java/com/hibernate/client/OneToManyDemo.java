package com.hibernate.client;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.model.Employee;
import com.hibernate.model.Project;

public class OneToManyDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory factory = new Configuration().configure().buildSessionFactory();

		Employee emp = new Employee();
		emp.setEmpId(1);
		emp.setName("abcd");

		Project p = new Project();
		p.setpId(101);
		p.setProName("Hostel man sys..");
		p.setDuration("6-month");
		p.setEmployee(emp);

		Project p1 = new Project();
		p1.setpId(102);
		p1.setProName("ATM man sys..");
		p1.setDuration("4-month");
		p1.setEmployee(emp);

		Project p2 = new Project();
		p2.setpId(103);
		p2.setProName("ABC man sys..");
		p2.setDuration("2-month");
		p2.setEmployee(emp);

		List<Project> list = new ArrayList<Project>();
		list.add(p);
		list.add(p1);
		list.add(p2);

		emp.setProject(list);

		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		
		session.save(emp);
		session.save(p);
		session.save(p1);
		session.save(p2);

		tx.commit();
		session.close();
		factory.close();

	}

}
