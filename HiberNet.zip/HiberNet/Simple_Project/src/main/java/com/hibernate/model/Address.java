package com.hibernate.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "Address_Details")
public class Address {

	@Id
	@Column(name = "Id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int addId;

	@Column(name = "AdCity")
	private String city;

	@Column(name = "Country")
	private String country;

	@Column(name = "StreetWay")
	private String street;

	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Address(int addId, String city, String country, String street) {
		super();
		this.addId = addId;
		this.city = city;
		this.country = country;
		this.street = street;
	}

	public int getAddId() {
		return addId;
	}

	public void setAddId(int addId) {
		this.addId = addId;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	@Override
	public String toString() {
		return "Address [addId=" + addId + ", city=" + city + ", country=" + country + ", street=" + street + "]";
	}

}
