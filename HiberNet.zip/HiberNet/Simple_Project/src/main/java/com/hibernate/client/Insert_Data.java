package com.hibernate.client;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.model.Address;


public class Insert_Data {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Configuration cfg=new Configuration();
		cfg.configure();
		SessionFactory factory=cfg.buildSessionFactory();
		
		
		Address ad=new Address(1,"Nashik","India","Nampur_Road");
		System.out.println("-----------------------");
		
		
		Session session=factory.openSession();
		Transaction tx = session.beginTransaction();
		
		session.save(ad);
		
//		Address address = session.get(Address.class, 1);
//		System.out.println(address);
		
		tx.commit();
		session.close();
		factory.close();
	}

}
