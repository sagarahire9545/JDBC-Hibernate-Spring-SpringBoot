package com.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Student {

	@Id
	private int roll_no;
	private String name;
	
	@Column(name = "`add`")
	private String add;

	public Student() {
		// TODO Auto-generated constructor stub
	}

	public Student(int roll_no, String name, String add) {
		this.roll_no = roll_no;
		this.name = name;
		this.add = add;
	}

	public int getRoll_no() {
		return roll_no;
	}

	public void setRoll_no(int roll_no) {
		this.roll_no = roll_no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAdd() {
		return add;
	}

	public void setAdd(String add) {
		this.add = add;
	}

	@Override
	public String toString() {
		return "Student [roll_no=" + roll_no + ", name=" + name + ", add=" + add + "]";
	}
	

}
