package com.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestEmployee {

    public static void main(String[] args) {

        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        SessionFactory factory = cfg.buildSessionFactory();

        Employee employee = new Employee();
        // No need to set emp_id manually if it's generated automatically
        // employee.setEmp_id(1);
        employee.setEmpName("Raj");
        employee.setEmpAdd("Satana");

        Session session = factory.openSession();
        Transaction transaction = session.beginTransaction();
        session.save(employee);
        
        Employee emp = session.get(Employee.class, 1);
        System.out.println(emp);
        
        transaction.commit();
        session.close();
        factory.close();
    }
}
