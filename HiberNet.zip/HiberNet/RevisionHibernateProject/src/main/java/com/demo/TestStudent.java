package com.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestStudent {

	public static void main(String[] args) {

        System.out.println( "Project started............." );

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

		Student student = new Student();
		student.setRoll_no(16);
		student.setName("Naru");
		student.setAdd("Satana");

		System.out.println(student);

		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(student);
		
		tx.commit();
		session.close();
		factory.close();
		
	}

}
