package com.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class FetchStudent {

	public static void main(String[] args) {

		System.out.println("Project started....");
		
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		
		Session session = factory.openSession();
		
//		Student student=session.get(Student.class,14);
		
		Student student=session.load(Student.class, 15);
		System.out.println(student);
		
		session.close();
		factory.close();
	}

}
