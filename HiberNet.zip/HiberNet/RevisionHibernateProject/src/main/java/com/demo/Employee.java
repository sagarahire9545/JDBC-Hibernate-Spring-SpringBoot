package com.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Employee")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Employee_Id")
    private int emp_id;

    @Column(name = "Employee_Name")
    private String empName;

    @Column(name = "Address")
    private String empAdd;

    public Employee() {
        super();
    }

    public Employee(int emp_id, String empName, String empAdd) {
        super();
        this.emp_id = emp_id;
        this.empName = empName;
        this.empAdd = empAdd;
    }

    public int getEmp_id() {
        return emp_id;
    }

    public void setEmp_id(int emp_id) {
        this.emp_id = emp_id;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmpAdd() {
        return empAdd;
    }

    public void setEmpAdd(String empAdd) {
        this.empAdd = empAdd;
    }

    @Override
    public String toString() {
        return "Employee [emp_id=" + emp_id + ", empName=" + empName + ", empAdd=" + empAdd + "]";
    }
}
