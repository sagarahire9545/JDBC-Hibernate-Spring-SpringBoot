package com.embeddable.example;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Person {

	@Id
	private int pId;
	private String name;

	private Address address;

	public Person() {
		super();
	}

	public Person(int pId, String name, Address address) {
		super();
		this.pId = pId;
		this.name = name;
		this.address = address;
	}

	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Person [pId=" + pId + ", name=" + name + ", address=" + address + "]";
	}

}
