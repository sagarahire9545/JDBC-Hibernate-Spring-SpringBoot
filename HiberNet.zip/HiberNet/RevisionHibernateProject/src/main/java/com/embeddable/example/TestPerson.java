package com.embeddable.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestPerson {

	public static void main(String[] args) {

		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		
		Person person=new Person();
		person.setpId(20);
		person.setName("Sagar");

        Address address=new Address();
        address.setCountry("India");
        address.setCity("Nashik");
        address.setStreet("Nampur-road");
        address.setZip(423204);
        
        person.setAddress(address);
        
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        session.save(person);
        
        tx.commit();
        session.close();
		factory.close();
	}

}
