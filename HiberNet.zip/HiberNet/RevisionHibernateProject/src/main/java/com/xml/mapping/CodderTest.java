package com.xml.mapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class CodderTest {

	public static void main(String[] args) {

		Configuration cfg=new Configuration();
		cfg.configure();
		SessionFactory factory=cfg.buildSessionFactory();
		

		Codder codder = new Codder();
		codder.setName("sagar");
		codder.setAdd("Nashik");
		//Codder codder1 = new Codder(12, "Amit", "Satana");
		
//		Session session = factory.openSession();
//        Transaction tx = session.beginTransaction();
		
		Session session= factory.openSession();
		Transaction tx = session.beginTransaction();
        
        session.save(codder);
        //session.save(codder1);
        
        
		tx.commit();
		session.close();
		factory.close();
	}

}
