package com.hql.practice;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.demo.Student;

public class UpdateQuery {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();

		String query = "update Student as s set s.add=:a where s.name=:n";

		Query q = session.createQuery(query);
		q.setParameter("a", "Ambasan");
		q.setParameter("n", "Sagar");
		
		int r=q.executeUpdate();
		System.out.println(r+ "Updated record.............");
		

		tx.commit();
		factory.close();
	}
}
