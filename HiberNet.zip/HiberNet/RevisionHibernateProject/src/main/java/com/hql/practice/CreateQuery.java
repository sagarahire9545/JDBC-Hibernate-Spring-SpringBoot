package com.hql.practice;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.demo.Employee;
import com.demo.Student;

public class CreateQuery {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		String query = "from Student as a where a.add=:x";

		
		Query q = session.createQuery(query);
		q.setParameter("x", "Nashik");
		List<Student> list = q.list();

		for (Student e : list) {
			System.out.println(e);
		}

		factory.close();
	}

}
