package com.hql.practice;

import org.hibernate.query.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DeleteQuery {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();

		String q="delete from Student where roll_no=:d";
		
		Query query=session.createQuery(q);
		query.setParameter("d", 15);
		
		int del=query.executeUpdate();
		System.out.println(del+"Record deleted.........");

		tx.commit();
		factory.close();
	}

}
