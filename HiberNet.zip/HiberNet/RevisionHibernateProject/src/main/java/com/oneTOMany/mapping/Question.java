package com.oneTOMany.mapping;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Questions")
public class Question {

	@Id
	@Column(name = "Question_Id")
	private int qId;
	
	private String que;

	@OneToMany(mappedBy = "question" ,fetch = FetchType.EAGER)
	List<Answer> answrer;

	public Question() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Question(int qId, String que, List<Answer> answrer) {
		super();
		this.qId = qId;
		this.que = que;
		this.answrer = answrer;
	}

	public int getqId() {
		return qId;
	}

	public void setqId(int qId) {
		this.qId = qId;
	}

	public String getQue() {
		return que;
	}

	public void setQue(String que) {
		this.que = que;
	}

	public List<Answer> getAnswrer() {
		return answrer;
	}

	public void setAnswrer(List<Answer> answrer) {
		this.answrer = answrer;
	}

	@Override
	public String toString() {
		return "Question [qId=" + qId + ", que=" + que + ", answrer=" + answrer + "]";
	}
	
}
