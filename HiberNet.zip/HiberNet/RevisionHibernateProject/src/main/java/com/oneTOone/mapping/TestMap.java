package com.oneTOone.mapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.SharedSessionContract;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestMap {

	public static void main(String[] args) {

		Configuration cfg=new Configuration();
		cfg.configure();
		SessionFactory factory = cfg.buildSessionFactory();
		
		Employee employee=new Employee();
		employee.setEmpId(11);
		employee.setName("Ram");
		
		Address address=new Address();
        address.setCity("Satara");
        address.setZip(1234);
        address.setEmployee(employee);

        employee.setAddress(address);
        
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        
        session.save(employee);
        session.save(address);
        
        tx.commit();
        session.close();	
		factory.close();
	}

}
