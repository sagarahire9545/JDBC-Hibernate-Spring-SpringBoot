package co.manyTOmany.mapping;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

		Programmer programmer = new Programmer();
		programmer.setpId(11);
		programmer.setName("Ram");

		Programmer programmer1 = new Programmer();
		programmer1.setpId(12);
		programmer1.setName("Shyam");

		Programmer programmer2 = new Programmer();
		programmer2.setpId(13);
		programmer2.setName("Hemraj");

		Project project = new Project();
		project.setProId(101);
		project.setProName("Hostel Man System");

		Project project1 = new Project();
		project1.setProId(102);
		project1.setProName("Gym Man System");

		Project project2 = new Project();
		project2.setProId(103);
		project2.setProName("Dabbawala Man System");

		List<Programmer> list = new ArrayList<Programmer>();
		list.add(programmer);
		list.add(programmer1);
		list.add(programmer2);

		List<Project> list1 = new ArrayList<Project>();
		list1.add(project);
		list1.add(project1);
		list1.add(project2);
		
		List<Project> list2 = new ArrayList<Project>();
		list2.add(project1);
		list2.add(project2);
		
		programmer2.setProjects(list2);
		

		programmer.setProjects(list1);
		project.setProgrammers(list);

		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();

		session.save(project);
		session.save(project1);
		session.save(project2);

		session.save(programmer);
		session.save(programmer1);
		session.save(programmer2);

		tx.commit();
		session.close();
		factory.close();
	}

}
