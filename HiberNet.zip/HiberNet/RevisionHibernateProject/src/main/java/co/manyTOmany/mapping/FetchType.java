package co.manyTOmany.mapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class FetchType {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		
		
	    Session session = factory.openSession();
		
		Programmer programmer=session.get(Programmer.class, 11);
        		System.out.println(programmer.getpId());
		
		session.close();
		factory.close();

	}

}
