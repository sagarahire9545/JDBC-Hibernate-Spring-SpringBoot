package co.manyTOmany.mapping;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Programmer_Details")
public class Programmer {

	@Id
	@Column(name = "Programmer_Id")
	private int pId;

	@Column(name = "Programmer_Name")
	private String name;

	@ManyToMany(fetch =FetchType.EAGER)
	@JoinTable(name = "Programmer_Projects")
	List<Project> projects;

	public Programmer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Programmer(int pId, String name, List<Project> projects) {
		super();
		this.pId = pId;
		this.name = name;
		this.projects = projects;
	}

	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Project> getProjects() {
		return projects;
	}

	public void setProjects(List<Project> projects) {
		this.projects = projects;
	}

	@Override
	public String toString() {
		return "Programmer [pId=" + pId + ", name=" + name + ", projects=" + projects + "]";
	}

}
