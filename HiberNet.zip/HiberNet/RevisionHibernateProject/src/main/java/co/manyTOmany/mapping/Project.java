package co.manyTOmany.mapping;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Project_Detail")
public class Project {

	@Id
	@Column(name = "Project_Id")
	private int proId;

	@Column(name = "Project_Name")
	private String proName;

	@ManyToMany(mappedBy = "projects")
	List<Programmer> programmers;

	public Project() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Project(int proId, String proName, List<Programmer> programmers) {
		super();
		this.proId = proId;
		this.proName = proName;
		this.programmers = programmers;
	}

	public int getProId() {
		return proId;
	}

	public void setProId(int proId) {
		this.proId = proId;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public List<Programmer> getProgrammers() {
		return programmers;
	}

	public void setProgrammers(List<Programmer> programmers) {
		this.programmers = programmers;
	}

	@Override
	public String toString() {
		return "Project [proId=" + proId + ", proName=" + proName + ", programmers=" + programmers + "]";
	}

}
