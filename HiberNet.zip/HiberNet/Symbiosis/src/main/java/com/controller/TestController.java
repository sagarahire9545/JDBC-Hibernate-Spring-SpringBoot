package com.controller;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.model.Customer;

public class TestController {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("e");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();

		Customer c1 = new Customer(10, "Sagar");
		Customer c2 = new Customer(11, "Nac");

		String query = "from Customer";

		em.find(Customer.class, c1);

		em.persist(c1);
		em.persist(c2);
		em.getTransaction().commit();
		System.out.println("Object persist");

	}

}
